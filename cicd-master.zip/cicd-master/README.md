# cicd
Implementing CICD with GCP Cloud Build / Skaffold to GKE deployment


Creating a node hello world app and integrating with cloud build and cloud run to check CICD pipeline.
Creating local development setup for deployment using SKAFFOLD. Build and Deploy. 

https://abhishekx.medium.com/skaffold-to-gke-deployment-240d38ee368e
